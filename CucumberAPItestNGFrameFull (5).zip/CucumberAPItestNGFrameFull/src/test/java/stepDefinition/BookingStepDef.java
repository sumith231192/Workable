package stepDefinition;

import helper.WaitUtil;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebElement;
import pageObject.TTBookingsPage;
import pageObject.TTHomePage;
import pageObject.TTManageAccountsOpenAndCloseAccounts;
import utility.DriverManager;
import utility.GenericPage;
import utility.TestDataReader;

import java.util.Arrays;
import java.util.List;

import static org.testng.Assert.assertEquals;

public class BookingStepDef {
	
	private WebDriver driver = DriverManager.getInstace().getDriver();

	private TTHomePage homePage = new TTHomePage(driver);
	private GenericPage genericPage = new GenericPage(driver);

	private TTBookingsPage bookingPage = new TTBookingsPage(driver);
	private TTManageAccountsOpenAndCloseAccounts manageAccountsOpenAndCloseAccounts = new TTManageAccountsOpenAndCloseAccounts(
			driver);
	private TestDataReader testDataReaderUI = new TestDataReader("TestDataUI");
	private TestDataReader testDataReaderTC = new TestDataReader("TestDataTC");

	WaitUtil waitUtil = new WaitUtil();

	
	@Given("User navigate to  Booking screen")
	public void user_navigate_to_Booking_screen() {
		
		homePage.navigateToBooking();
	}

	@Then("User navigate to Unmatched Booking")
	public void user_navigate_to_Unmatched_Booking() {
		
		bookingPage.navigateToUnMatched();
	   
	}
	@Then("User validates {string} in Bookings page")
	public void user_vlidates_in_Bookings_page(String string) {
	
		genericPage.validateColumnValuesInrowHead(
				testDataReaderUI.getDataFromTestData().get(string));
		genericPage
				.validateMenuVlauesInRowHead(testDataReaderUI.getDataFromTestData().get(string));
		genericPage
				.validatePingColumnOptions(testDataReaderUI.getDataFromTestData().get(string));
	}

	@Then("User navigate to Matched Booking")
	public void user_navigate_to_Matched_Booking() {
	    bookingPage.navigateToMatched();
	}

	@Then("User navigate to Exceptions Booking")
	public void user_navigate_to_Exceptions_Booking() {
	    bookingPage.navigateToExceptions();
	}
	
	@Then("User removes all filters")
	public void user_removes_all_filters() {
		
	  
	}

	@Then("User validates {string} in Unmatched Booking Page")
	public void user_validates_in_Unmatched_Booking_Page(String string) {
		bookingPage.navigateToUnMatched();
	}


	@When("User should be able to view {string} fields")
			public void user_should_be_able_to_view_fields(){


	}


}
