package stepDefinition;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObject.HistoricalPage;
import pageObject.TTHistoricalEOD;
import pageObject.TTHomePage;
import pageObject.TTLoginPage;
import utility.DriverManager;

public class TTHistoricalEODSteps {

	private WebDriver driver = DriverManager.getInstace().getDriver();

	TTLoginPage ttLoginPage = null;
	TTHomePage ttHomePage = null;
	TTHistoricalEOD ttHistoricalEOD = null;
	HistoricalPage historicalPage = null;

	@Given("User has navigated to Historical EOD")
	public void user_has_navigated_to_historical_eod() {

		ttLoginPage = new TTLoginPage(driver);
		ttLoginPage.navigateToTTHomepage();
		ttHomePage = new TTHomePage(driver);
		ttHomePage.navigateToHistoricalEOD();
	}

	@When("User enters clicks on EOD Balances Tab")
	public void user_clicks_on_eod_balances_tab() {
		ttHistoricalEOD.clickEOD();
	}

	@When("User enters EOD details on Search Tab")
	public void user_eod_enters_details_in_search_tab() throws Exception {
		ttHistoricalEOD.searchEODBalances();
	}

	@Then("EOD transaction should be displayed when search button clicked")
	public void eod_transction_should_be_displayed_when_search_button_clicked() {
		ttHistoricalEOD.searchButton();

	}

	@Then("EOD Screen should be refreshed")
	public void eod_screen_should_be_refreshed() throws Exception {
		ttHistoricalEOD.resetButton();

	}
	
	
	
	@Then("^Uer should be abel to view \"([^\"]*)\" and \"([^\"]*)\"$")
	public void uer_should_be_abel_to_view_and(String arg1, String arg2){
		
		historicalPage = new HistoricalPage(driver);
		historicalPage.validateTabPresent(arg1);
		historicalPage.validateTabPresent(arg2);
	}

	


	@Then("^Usernavigate to Payemnt Tab$")
	public void usernavigate_to_Payemnt_Tab() {
		historicalPage.navigateToPaymentsTab();
		
	}

	@Then("^User should be ane to view the respective \"([^\"]*)\"  of Payemnt Tab$")
	public void user_should_be_ane_to_view_the_respective_of_Payemnt_Tab(String arg1) {
	}
	
	
	@Then("^Usernavigate to EOD Balance tab$")
	public void usernavigate_to_EOD_Balance_tab(){
	}
	

	@Then("^User should be ane to view the respective options of EOD Balance tab$")
	public void user_should_be_ane_to_view_the_respective_options_of_EOD_Balance_tab() {
	}



}
