package stepDefinition;

import io.cucumber.java.en.Then;
import org.openqa.selenium.WebDriver;
import pageObject.TTManageAccounts;
import pageObject.TTManageAccountsOpenAndCloseAccounts;
import utility.DriverManager;
import utility.GenericPage;
import utility.TestDataReader;

import java.sql.SQLOutput;

public class ReconciliationStepDef {

    private WebDriver driver = DriverManager.getInstace().getDriver();

    private TTManageAccounts manageAccounts = new TTManageAccounts(driver);

    private GenericPage genericPage = new GenericPage(driver);
    private TTManageAccountsOpenAndCloseAccounts manageAccountsOpenAndCloseAccounts = new TTManageAccountsOpenAndCloseAccounts(
            driver);

    private TestDataReader testDataReaderUI = new TestDataReader("TestDataUI");
    private TestDataReader testDataReaderTC = new TestDataReader("TestDataTC");



    @Then("The user validates {string} details in Reconciliation Page")
    public void the_user_validates_details_in_Reconciliation_Page(String string) {
        System.out.println(string);
        genericPage.clickfilterIcon(string);

        genericPage.validateColumnValuesInrowHead(
                testDataReaderUI.getDataFromTestData().get("Recon_Columns"));
        genericPage.validateMenuVlauesInRowHead(testDataReaderUI.getDataFromTestData().get("OpenAccounts_Common_Menu"));
        genericPage.validatePingColumnOptions(testDataReaderUI.getDataFromTestData().get("PinColumnActions"));
    }

}
