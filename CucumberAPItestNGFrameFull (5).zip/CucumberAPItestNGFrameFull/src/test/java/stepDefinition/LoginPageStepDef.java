package stepDefinition;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import pageObject.TTLoginPage;
import utility.DriverManager;

public class LoginPageStepDef   {
	


	private WebDriver driver = DriverManager.getInstace().getDriver() ;
	private TTLoginPage loginpage = new TTLoginPage(driver);
	
	@Given("^User is in Treasury Terminal page$")
	public void user_is_in_Treasury_Terminal_page() {
		 
		loginpage.navigateToTTHomepage();

	}

	@Then("User close the browser")
	public void user_close_the_browser() {
		DriverManager.getInstace().closeDriver();
	}
}
