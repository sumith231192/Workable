package stepDefinition;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import pageObject.TTHomePage;
import utility.DriverManager;

public class HomepageStefDef   {

	private WebDriver driver = DriverManager.getInstace().getDriver() ;
	private TTHomePage homePage = new TTHomePage(driver);
	
	
	@Given("^User navigate to Accounts Tab$")
	public void user_navigate_to_Accounts_Tab() {

		homePage.navigateToAccountsPage();

	}
	@Given("User navigate to Reconciliation Tab")
	public void user_navigate_to_Reconciliation_Tab() {
			homePage.navigateToReconciliation();
	}
	
}
