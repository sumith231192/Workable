//package stepDefinition;
//
//import static org.testng.Assert.assertEquals;
//
//import java.util.Arrays;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import org.openqa.selenium.WebDriver;
//import org.testng.Assert;
//
//import com.google.gson.JsonElement;
//import com.google.gson.JsonObject;
//import com.google.gson.JsonParser;
//
//import helper.APIhelper;
//import io.cucumber.java.en.Given;
//import io.cucumber.java.en.Then;
//import io.cucumber.java.en.When;
//import io.restassured.RestAssured;
//import io.restassured.http.ContentType;
//import io.restassured.path.json.JsonPath;
//import io.restassured.response.Response;
//import io.restassured.specification.RequestSpecification;
//import pageObject.TTLoginPage;
//import pojo.Accounts;
//import utility.ConfigFileReader;
//import utility.DriverManager;
//import utility.TestDataReader;
//
//public class API {
//	private DriverManager webDriverManager = new DriverManager();
//	private WebDriver driver = webDriverManager.getDriver();
//	private TTLoginPage loginpage = new TTLoginPage(driver);
//	private APIhelper apIhelper = new APIhelper(driver);
//	private ConfigFileReader configFileReader = new ConfigFileReader();
//	private TestDataReader testDataReaderTC = new TestDataReader("TestDataTC");
//	private TestDataReader testDataReaderUI = new TestDataReader("TestDataUI");
//	RestAssured restAssured = new RestAssured();
//	RequestSpecification httpRequest;
//	Response response;
//	String resString;
//	JsonPath js;
//
//	@Given("User hits api {string}")
//	public void user_hits_api(String string) {
//		restAssured.baseURI = string;
//	}
//
//	@When("User send Http send req {string}")
//	public void user_send_Http_send_req(String string) {
//		restAssured.basePath = string;
//	}
//
//	@Then("User set Auth token")
//	public void user_set_Auth_token() {
//		String acctocken = loginpage.getauthcodeForAPI();
//		Map<String, String> queryParam = new HashMap<String, String>();
//		httpRequest = RestAssured.given().auth().oauth2(acctocken);
//
//	}
//	@Then("User get the responce as Json")
//	public void user_get_the_responce_as_Json() {
//		String acctocken = loginpage.getauthcodeForAPI();
//		Map<String, String> queryParam = new HashMap<String, String>();
//		response = httpRequest.given().accept(ContentType.JSON).when().get();
//
//	}
//
//	@Then("User get json for {string} with {string} as query parameter")
//	public void user_get_json_for_with_as_query_parameter(String key, String value) {
//		Map<String, String> queryParam = new HashMap<String, String>();
//		queryParam.put(key, value);
//		response = httpRequest.given().accept(ContentType.JSON).param(key, value).when().queryParam(key, value).get();
//		/*
//		 * System.out.println(response.getBody().asString());
//		 * apIhelper.createJsonFile(response.getBody().asString());
//		 */
//
//	}
//
//	@Then("User vlaidate {string} is {string}")
//	public void user_validate_Key_Value(String key, String value) {
//		JsonElement jsonElement = new JsonParser().parse(response.asString().replace("[", "").replace("]", ""));
//		JsonObject jsonObject = jsonElement.getAsJsonObject();
//		assertEquals(jsonObject.get(key).getAsString().replaceAll("\"", "").equals(value), true, "Validated JSON data");
//
//	}
//
//	@Then("User cheks  the status code {string}")
//	public void user_cheks_the_status_code(String string) {
//		response = httpRequest.get();
//		int valueexp = Integer.valueOf(string);
//		int statusCode = response.getStatusCode();
//		Assert.assertEquals(statusCode /* actual value */, valueexp /* expected value */,
//				"Validated status code returned");
//	}
//
//	@Then("User Validate json  enity test data")
//	public void user_Validate_json_enity_test_data() {
//		String resString = response.asString();
//		JsonPath jsonPath = new JsonPath(resString);
//		String[] lealentArr = jsonPath.getString("entity").replace("[", "").replace("]", "").split(",");
//		List<String> legArrayList = Arrays.asList(lealentArr);
//		String[] legArrData = testDataReaderUI.getDataFromTestData().get("Legal_Entity_Filter").split(",");
//		for (String data : lealentArr) {
//			assertEquals(legArrayList.contains(data), true, "Validating Legal Entry");
//		}
//
//	}
//
//	@Then("User get accout details accountNumber for test data for {string}")
//	public void user_get_accout_details_for_test_data_for(String TestCaseID) {
//
//		Accounts acc = apIhelper.getAccountDetailsFromPojo(response.asString());
//		testDataReaderTC.setTestDataforTCProperties(TestCaseID + ".accountNumber", acc.getAccountNumber());
//
//	}
//
//	@Then("User get the test data to Amend an account {string}")
//	public void user_get_the_test_data_to_Amend_an_account(String string) {
//		String value = js.get("accountNumber");
//		System.out.println(value);
//		configFileReader.setConfigProperty(string, value);
//	}
//
//	@Then("User get the test  data for Deactivate an account {string}")
//	public void user_get_the_test_data_for_Deactivate_an_account(String string) {
//
//	}
//
//}
