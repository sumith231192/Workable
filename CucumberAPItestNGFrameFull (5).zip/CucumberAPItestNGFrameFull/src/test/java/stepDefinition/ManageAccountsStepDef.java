package stepDefinition;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObject.TTManageAccounts;
import pageObject.TTManageAccountsOpenAndCloseAccounts;
import utility.DriverManager;
import utility.GenericPage;
import utility.TestDataReader;

public class ManageAccountsStepDef {

	private WebDriver driver = DriverManager.getInstace().getDriver();

	private TTManageAccounts manageAccounts = new TTManageAccounts(driver);

	private GenericPage genericPage = new GenericPage(driver);
	private TTManageAccountsOpenAndCloseAccounts manageAccountsOpenAndCloseAccounts = new TTManageAccountsOpenAndCloseAccounts(
			driver);

	private TestDataReader testDataReaderUI = new TestDataReader("TestDataUI");
	private TestDataReader testDataReaderTC = new TestDataReader("TestDataTC");

	@Then("User should be able to view AccountsTabValues")
	public void user_should_be_able_to_view_AccountsTabValues() {

		manageAccounts.validateTabPresent();

	}

	@Then("^User navigate to Open Accounts page$")
	public void user_navigate_to_Open_Accounts_page() {

		manageAccounts.navigateToOpenAccounts();

	}

	@Then("^User navigate to Close Accounts Page$")
	public void user_navigate_to_Close_Accounts_Page() {
		manageAccounts.navigateToCloseAccounts();
	}

	@Then("^User should be able to view below \"([^\"]*)\" displayed$")
	public void user_should_be_able_to_view_below_displayed(String arg1) {

		genericPage.validateAllrowHeadingsIsDisaplyed(testDataReaderUI.getDataFromTestData().get(arg1));
	}

	@When("User clicks on Options {string} should be displayed")
	public void user_clicks_on_Options_should_be_displayed(String string) {
		manageAccountsOpenAndCloseAccounts.verifyOptinsLeads(testDataReaderUI.getDataFromTestData().get(string));

	}

	@Then("Use should be able to view Summary panel with {string} and {string}")
	public void use_should_be_able_to_view_Summary_panel_with_and(String string, String string2) {
		genericPage.validaterowSummaryPanel(testDataReaderUI.getDataFromTestData().get(string));
		genericPage.validatePageSummarPannel(testDataReaderUI.getDataFromTestData().get(string2));
	}

	@Then("User clicks on the {string} filter button")
	public void user_clicks_on_the_filter_button(String string) {
		genericPage.clickfilterIcon(string);
	}

	@Then("User {string} filter options of {string}")
	public void user_validates_fliter_options_of(String validation, String string) {
		if (validation.equalsIgnoreCase("validates")) {
			genericPage.validateFiltervaluesInROwHead(testDataReaderUI.getDataFromTestData().get(string));
		}
	}

	@Then("User validates Columns options in {string}")
	public void user_validates_Columns_options_in(String string) {
		genericPage.validateColumnValuesInrowHead(testDataReaderUI.getDataFromTestData().get(string));

	}

	@Then("User validates Menu options in {string}")
	public void user_validates_Menu_options_in(String string) {
		genericPage.validateMenuVlauesInRowHead(testDataReaderUI.getDataFromTestData().get(string));
		genericPage.validatePingColumnOptions(testDataReaderUI.getDataFromTestData().get("PinColumnActions"));

	}

	@Then("The user validates {string} details in Open Account Page")
	public void the_user_validates_details(String string) {
		genericPage.clickfilterIcon(string);
//		if (string.equalsIgnoreCase("Legal Entity")) {
//			genericPage
//					.validateFiltervaluesInROwHead(testDataReaderUI.getDataFromTestData().get("Legal_Entity_Filter"));
//		}
		genericPage.validateColumnValuesInrowHead(
				testDataReaderUI.getDataFromTestData().get("OpenAccounts_Common_Columns"));
		genericPage.validateMenuVlauesInRowHead(testDataReaderUI.getDataFromTestData().get("OpenAccounts_Common_Menu"));
		genericPage.validatePingColumnOptions(testDataReaderUI.getDataFromTestData().get("PinColumnActions"));

	}

	@Given("User clicks on resize row for all rows")
	public void user_clicks_on_resize_row_for_allrows() {
		genericPage.clickResize();
	}

	@Then("The user validates {string} details in Close Account Page")
	public void the_user_validates_details_in_Close_Account_Page(String string) {
		genericPage.clickfilterIcon(string);

		genericPage.validateColumnValuesInrowHead(
				testDataReaderUI.getDataFromTestData().get("ClosedAccounts_Common_Columns"));
		genericPage
				.validateMenuVlauesInRowHead(testDataReaderUI.getDataFromTestData().get("ClosedAccounts_Common_Menu"));
		genericPage.validatePingColumnOptions(testDataReaderUI.getDataFromTestData().get("PinColumnActions"));

	}

	@Then("User clicks on {string} filter button")
	public void the_use_click_on_filter_button(String string) {

		genericPage.clickfilterIcon(string);

	}

	@Then("User clicks SelectAll")
	public void user_removes_all_the_slected() {
		genericPage.clickSelectAll();
	}

	@When("User select {string} filters from {string} only that entry should be displayed in Filter Row")
	public void then_the_user_slects_filters_from_only_that_entry_should_be_displayed(String FilterCout,
			String Legal_Entity_Filter) {
		manageAccountsOpenAndCloseAccounts.validateValueDisplayedAfterClearFilter(
				testDataReaderUI.getDataFromTestData().get("Legal_Entity_Filter"), FilterCout);

	}

	@Then("User clicks on ClearFilter")
	public void user_clicks_on_ClearFilter() {
		genericPage.clickClearFilterButton();
	}

	@Then("User navigate to filter column")
	public void user_navigate_to_filter_column() {
		genericPage.clickIconColumn();

	}

	@When("User select value one by one the only the selected value should be displayed")
	public void user_select_value_one_by_one_the_only_the_selected_value_should_be_displayed() {
		genericPage.validateTheColumFilterOneByOne();
	}

	@Then("user select {string} filters from {string} only that entry should be displayed in Filter Columns")
	public void user_select_filters_from_only_that_entry_should_be_displayed(String FilterCoutColumn,
			String valuefromTD_UI) {
		genericPage.validateValueDisplayedAfterClearColumnFilter(
				testDataReaderUI.getDataFromTestData().get(valuefromTD_UI), FilterCoutColumn);
	}

	@When("User select segregation as {string} only the respective segregation list should be displayed")
	public void user_select_segregation_as_only_the_respetive_segregation_list_should_be_displayed(String string) {

		manageAccountsOpenAndCloseAccounts.slectSegregationList(string);
	}

	@When("User select value one by one from {string} only respective selected data value data should be displayed")
	public void user_select_value_one_by_one_from_filterlist_only_respective_selected_data_value_data_should_be_displayed(
			String filterData) {
		genericPage
				.validateFilterOnebyOneWithFilterValueAndData(testDataReaderUI.getDataFromTestData().get(filterData));
	}

	@Then("User selects {string} from drop down and enters {string} the data should be displayed as expected")
	public void user_selects_from_dropDown_and_enters_the_data_should_be_displayed_as_expected(String selectValue,
			String dateValue) {
		manageAccountsOpenAndCloseAccounts.vlidateSwiftDateValue(selectValue, dateValue);

	}

	@Then("User selects {string} from drop down and enters rage from {string}  and range to {string} in the data should be displayed as expected")
	public void user_selects_from_dropDown_and_enters_rage_from_and_range_to_in_the_data_should_be_displayed_as_expected(
			String slectValue, String dateFrom, String dateTo) {
		manageAccountsOpenAndCloseAccounts.vlidateSwiftDateValue_InRange(slectValue, dateFrom, dateTo);
	}

	@When("User enter search box with {string} data should be displayed in filter")
	public void user_enter_search_box_with_data_should_be_displyed_in_filter(String data) {
		manageAccountsOpenAndCloseAccounts.setSearchFilter(testDataReaderTC.getDataFromTestData().get(data));

	}

	@Then("User select the {string} data to apply filter")
	public void user_select_the_data_to_apply_filter(String data) {
		genericPage.selectSearchFilter(testDataReaderTC.getDataFromTestData().get(data));
	}

	@Then("The selected data {string} should be displayed")
	public void the_selected_data_should_be_displayed(String data) {
		manageAccountsOpenAndCloseAccounts
				.validateAccountNumberDispayedInDataAfterfilter(testDataReaderTC.getDataFromTestData().get(data));
		manageAccountsOpenAndCloseAccounts.clickManageAcoountHeader();
	}

	@Then("User clicks on {string} row")
	public void user_clicks_on_row(String data) {
		manageAccountsOpenAndCloseAccounts
				.doubleClickAccounNumbetInColumn(testDataReaderTC.getDataFromTestData().get(data));

	}

	@Then("User should be able to view pop up window with {string} at header")
	public void user_should_be_able_to_view_pop_up_window_with_at_header(String data) {
		manageAccountsOpenAndCloseAccounts
				.validateAccountDetailsPopUpHeaderDisplayed(testDataReaderTC.getDataFromTestData().get(data));
	}

	@Then("User should be able to view pop up window with {string} at the header")
	public void user_should_be_able_to_view_pop_up_window_with_at_the_header(String headerData) {
		manageAccountsOpenAndCloseAccounts.validateAccountDetailsPopUpHeaderDisplayed(headerData);
	}

	@Then("The {string} should be displayed as expected")
	public void the_should_be_displyed_as_expected(String data) {
		manageAccountsOpenAndCloseAccounts
				.validateAccountPopupDilogBoxLabels(testDataReaderUI.getDataFromTestData().get(data));
	}

	@Then("User enters Bank Cut Off Time as {string}")
	public void user_enters(String bankcutofftime) {

		manageAccountsOpenAndCloseAccounts.setBankCutOffTimeAccountPopupDilogBoxDetails(bankcutofftime);
	}

	@Then("User clicks save button in the account detail dialog box")
	public void use_cliks_save_button_in_the_account_detail_dialog_box() {
		manageAccountsOpenAndCloseAccounts.clickSaveAccountDetails();
	}

	@Then("The Account number with {string} should be marked as {string} with {string} and status as {string}")
	public void the_Account_number_with_should_be_maked_as_with_and_status_as(String accountnum, String Color,
			String ColorHexa, String AccountStatus) {
		manageAccountsOpenAndCloseAccounts.validateColorstatusAcoount(Color,
				testDataReaderTC.getDataFromTestData().get(accountnum), ColorHexa, AccountStatus);
	}

	@Then("User clicks on Deactivate button in the account detail dialog box")
	public void user_clicks_on_Deactivate_button_in_the_account_detail_dialog_box() {
		manageAccountsOpenAndCloseAccounts.clickDeactivateButtonAccountDetailsPopUp();

	}

	@Then("User select legal entity  {string}")
	public void user_select_legal_entity(String legentity) {
		manageAccountsOpenAndCloseAccounts.slectlegalEntiti(legentity);
	}

	@Then("Data displayed should have only the legal entity {string}")
	public void data_displyayed_should_have_only_the_leagl_entity(String legentity) {
		manageAccountsOpenAndCloseAccounts.validateDataPresentByLegalEniti(legentity);
	}
}
