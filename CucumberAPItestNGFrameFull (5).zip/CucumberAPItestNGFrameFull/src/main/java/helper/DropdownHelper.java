package helper;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

/*This Class Under Helper Package is used to handle drop down functions in web page
on the web page  */

public class DropdownHelper {
	
	private static DropdownHelper drodownHelper;
	private static WebDriver wdDrvier;
	
	public DropdownHelper(WebDriver driver){
		wdDrvier = driver;
	}
	
	public static DropdownHelper getInstance(WebDriver driver){
		if(drodownHelper == null || wdDrvier.hashCode() != driver.hashCode())
			drodownHelper = new DropdownHelper(driver);
		return drodownHelper;
	}
	
	/** Select by using Visible Text In Drop down
	 * @param locator :- unique 
	 * @param visibleValue :- UI value
	 */
	public void selectByVisibleText(By locator,String visibleValue){
		Select select = new Select(wdDrvier.findElement(locator));
		select.selectByVisibleText(visibleValue);
	}
	
	/** Select by using Index  In Drop down
	 * @param locator
	 * @param index :- Index of the value to be selected
	 */
	public void selectByIndex(By locator,int index){
		Select select = new Select(wdDrvier.findElement(locator));
		select.selectByIndex(index);
		
	}
	
	/** Select by using value In Drop down
	 * @param locator
	 * @param valueAttribute :- Corresponding value attribute
	 */
	public void selectByValue(By locator,String valueAttribute){
		Select select = new Select(wdDrvier.findElement(locator));
		select.selectByValue(valueAttribute);
	}
	
	public void selectByValue(WebElement element,String valueAttribute){
		Select select = new Select(element);
		select.selectByValue(valueAttribute);
	}
	
	/** Get all Text from Drop down
	 * @param locator
	 * @return List<WebElement> : Each element in list repre a value in drop down
	 */
	public List<WebElement> getAllValues(By locator){
		Select select = new Select(wdDrvier.findElement(locator));
		return select.getOptions();
	}

}
