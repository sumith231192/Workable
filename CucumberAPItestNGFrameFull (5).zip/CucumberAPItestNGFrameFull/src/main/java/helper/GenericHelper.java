package helper;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import java.awt.Color;

/*This Class Under Helper Package is having common functions that is being used in total project  
on the web page  */
public class GenericHelper {

	private static GenericHelper genericHelper;
	private static WebDriver wdDriver;
	WaitUtil waitUtil = new WaitUtil();

	public GenericHelper(WebDriver driver) {
		wdDriver = driver;
	}

	public static GenericHelper getInstance(WebDriver driver) {
		if (genericHelper == null || wdDriver.hashCode() != driver.hashCode())
			genericHelper = new GenericHelper(driver);
		return genericHelper;
	}

	/*
	 * If dir is present , then save the screen shot in the given dir Create the
	 * dir, take the screen shot and save the screen shot in the dir File -> java
	 * framework
	 * 
	 */
	public String takeScrenShot(String aDir, String bFileName) {

		File directory = new File(aDir);

		if (!directory.exists())
			directory.mkdirs();

		String aPath = directory.getAbsolutePath() + File.separator + bFileName;

		return takeScreenShot(aPath);
	}

	public String takeScreenShot(String aPath) {
		File screenshot = ((TakesScreenshot) wdDriver).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(screenshot, new File(aPath));
		} catch (IOException e) {
			e.printStackTrace();
			return "";
		}
		return aPath;
	}

	public byte[] takeScrenShot() {
		byte[] screenshot = ((TakesScreenshot) wdDriver).getScreenshotAs(OutputType.BYTES);
		return screenshot;
	}

	/**
	 * Used to Zoom In Page
	 * 
	 * @param int
	 *            NUmber Of Times To zoom in
	 * 
	 */
	public void zoomIN(int Notimeszoom) {

		try {
			Robot robot = new Robot();
			System.out.println("About to zoom in");
			for (int i = 0; i < Notimeszoom; i++) {
				robot.keyPress(KeyEvent.VK_CONTROL);
				robot.keyPress(KeyEvent.VK_ADD);
				robot.keyRelease(KeyEvent.VK_ADD);
				robot.keyRelease(KeyEvent.VK_CONTROL);
			}

		} catch (Exception AWTException) {
			// TODO: handle exception
		}
		waitUtil.sleepSeconds(1);

	}

	/**
	 * Used to Zoom Out Page
	 * 
	 * @param int
	 *            NUmber Of Times To zoom out
	 * 
	 */
	public void zoomOUT(int Notimeszoom) {

		try {
			Robot robot = new Robot();
			for (int i = 0; i < 4; i++) {
				robot.keyPress(KeyEvent.VK_CONTROL);
				robot.keyPress(KeyEvent.VK_SUBTRACT);
				robot.keyRelease(KeyEvent.VK_SUBTRACT);
				robot.keyRelease(KeyEvent.VK_CONTROL);
			}
		} catch (Exception AWTException) {
			// TODO: handle exception
		}
		waitUtil.sleepSeconds(1);
	}

	/**
	 * Used to make the Page in to Normal
	 * 
	 * 
	 */
	public void zoomNOTMAL() {

		try {
			Robot robot = new Robot();

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_0);

		} catch (Exception AWTException) {
			// TODO: handle exception
		}
		waitUtil.sleepSeconds(1);
	}
	
    

}
