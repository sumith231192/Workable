package helper;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class WindowHelper {

	private static WindowHelper windowHelper;
	private static WebDriver wdDriver;
	private WebElement element;

	private WindowHelper(WebDriver driver) {
		wdDriver = driver;
	}

	public static WindowHelper getInstance(WebDriver driver) {
		if (windowHelper == null || wdDriver.hashCode() != driver.hashCode())
			windowHelper = new WindowHelper(driver);
		return windowHelper;
	}

	private List<String> getWindowIds() {
		ArrayList<String> windowIds = new ArrayList<>(wdDriver.getWindowHandles());
		return Collections.unmodifiableList(windowIds);
	}

	public void switchToWindow(int index) {

		ArrayList<String> windowIds = new ArrayList<>(getWindowIds());

		if (index < 0 || index > windowIds.size())
			throw new IllegalArgumentException("Index is not valid " + index);

		wdDriver.switchTo().window(windowIds.get(index));

	}

	public void switchToParent() {
		ArrayList<String> windowIds = new ArrayList<>(getWindowIds());
		wdDriver.switchTo().window(windowIds.get(0));
	}

	public void switchToParentWithClose() {
		ArrayList<String> windowIds = new ArrayList<>(getWindowIds());

		for (int i = 1; i < windowIds.size(); i++) {
			wdDriver.switchTo().window(windowIds.get(i));
			wdDriver.close();
		}

		switchToParent();
	}

	public void zoomIN(int Notimeszoom) {

		try {
			Robot robot = new Robot();
			System.out.println("About to zoom in");
			for (int i = 0; i < Notimeszoom; i++) {
				robot.keyPress(KeyEvent.VK_CONTROL);
				robot.keyPress(KeyEvent.VK_ADD);
				robot.keyRelease(KeyEvent.VK_ADD);
				robot.keyRelease(KeyEvent.VK_CONTROL);
			}

		} catch (Exception AWTException) {
			// TODO: handle exception
		}

	}

	public void zoomOUT(int Notimeszoom) {

		try {
			Robot robot = new Robot();
			for (int i = 0; i < 4; i++) {
				robot.keyPress(KeyEvent.VK_CONTROL);
				robot.keyPress(KeyEvent.VK_SUBTRACT);
				robot.keyRelease(KeyEvent.VK_SUBTRACT);
				robot.keyRelease(KeyEvent.VK_CONTROL);
			}
		} catch (Exception AWTException) {
			// TODO: handle exception
		}
	}

}
