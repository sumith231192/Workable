package helper;

import java.awt.Robot;
import java.awt.event.KeyEvent;

/*This Class Under Helper Package is having common functions that is being used in total project  
on the web page  */
public class CommonHelper {
	WaitUtil waitUtil = new WaitUtil();

	// Used to Zoom IN Page
	public void zoomIN(int Notimeszoom) {

		try {
			Robot robot = new Robot();
			System.out.println("About to zoom in");
			for (int i = 0; i < Notimeszoom; i++) {
				robot.keyPress(KeyEvent.VK_CONTROL);
				robot.keyPress(KeyEvent.VK_ADD);
				robot.keyRelease(KeyEvent.VK_ADD);
				robot.keyRelease(KeyEvent.VK_CONTROL);
			}

		} catch (Exception AWTException) {
			// TODO: handle exception
		}
		waitUtil.sleepSeconds(1);

	}

	// Used to Zoom Out Page
	public void zoomOUT(int Notimeszoom) {

		try {
			Robot robot = new Robot();
			for (int i = 0; i < 4; i++) {
				robot.keyPress(KeyEvent.VK_CONTROL);
				robot.keyPress(KeyEvent.VK_SUBTRACT);
				robot.keyRelease(KeyEvent.VK_SUBTRACT);
				robot.keyRelease(KeyEvent.VK_CONTROL);
			}
		} catch (Exception AWTException) {
			// TODO: handle exception
		}
		waitUtil.sleepSeconds(1);
	}

	// Used to Back to Normal ZOOM (Base Zoom 100)
	public void zoomNOTMAL() {

		try {
			Robot robot = new Robot();

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_0);

		} catch (Exception AWTException) {
			// TODO: handle exception
		}
		waitUtil.sleepSeconds(1);
	}

}
