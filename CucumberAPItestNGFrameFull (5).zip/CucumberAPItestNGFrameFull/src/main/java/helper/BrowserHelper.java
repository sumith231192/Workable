package helper;

import org.openqa.selenium.WebDriver;

/*This Class Under Helper Package is a utility made to handle Browser Functions  
on the web page  */
public class BrowserHelper {

	private static BrowserHelper browserHelper;
	private static WebDriver wdDrvier;

	private BrowserHelper(WebDriver driver) {
		wdDrvier = driver;
	}

	public static BrowserHelper getInstance(WebDriver driver) {
		if (browserHelper == null || wdDrvier.hashCode() != driver.hashCode())
			browserHelper = new BrowserHelper(driver);
		return browserHelper;
	}

	public void moveForward() {
		wdDrvier.navigate().forward();
	}

	public void moveBackword() {
		wdDrvier.navigate().back();
	}

	public void refresh() {
		wdDrvier.navigate().refresh();
	}

	public void maximize() {
		wdDrvier.manage().window().maximize();
	}

}
