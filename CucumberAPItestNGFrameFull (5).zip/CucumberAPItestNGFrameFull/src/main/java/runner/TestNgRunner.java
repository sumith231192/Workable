package runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(features="src/test/java/features/",
glue= {"stepDefinition"},
plugin = {"pretty", "json:target/report.json","de.monochromata.cucumber.report.PrettyReports:target/Testngpretty-cucumber"},
monochrome=true,
strict=true,
dryRun=false,
tags="@RECONCILIATION")

public class TestNgRunner extends AbstractTestNGCucumberTests {
	
}