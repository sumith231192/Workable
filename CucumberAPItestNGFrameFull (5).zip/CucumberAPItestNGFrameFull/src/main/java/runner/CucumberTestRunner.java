package runner;

import org.junit.runner.RunWith;


import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;


@RunWith(Cucumber.class)
@CucumberOptions(features="src/test/java/features/",
glue= {"stepDefinition"},
plugin = {"pretty", "json:target/report.json", "de.monochromata.cucumber.report.PrettyReports:target/pretty-cucumber"},
monochrome=true,
strict=true,
dryRun=false,
tags = "@UI")
public class CucumberTestRunner {
	
}

	