package pojo;

public  class LegalEntity {
	 private float id;
	 private String entity;
	 private String businessGroup;
	 private String backOfficeCode;
	 private String sharedBackOfficeCode = null;
	 private String country = null;

//	 LegalEntity() {}
	 // Getter Methods 

	 public float getId() {
	  return id;
	 }

	 public String getEntity() {
	  return entity;
	 }

	 public String getBusinessGroup() {
	  return businessGroup;
	 }

	 public String getBackOfficeCode() {
	  return backOfficeCode;
	 }

	 public String getSharedBackOfficeCode() {
	  return sharedBackOfficeCode;
	 }

	 public String getCountry() {
	  return country;
	 }

	 // Setter Methods 

	 public void setId(float id) {
	  this.id = id;
	 }

	 public void setEntity(String entity) {
	  this.entity = entity;
	 }

	 public void setBusinessGroup(String businessGroup) {
	  this.businessGroup = businessGroup;
	 }

	 public void setBackOfficeCode(String backOfficeCode) {
	  this.backOfficeCode = backOfficeCode;
	 }

	 public void setSharedBackOfficeCode(String sharedBackOfficeCode) {
	  this.sharedBackOfficeCode = sharedBackOfficeCode;
	 }

	 public void setCountry(String country) {
	  this.country = country;
	 }
	}