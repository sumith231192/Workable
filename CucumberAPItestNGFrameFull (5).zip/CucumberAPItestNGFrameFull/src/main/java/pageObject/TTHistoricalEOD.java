package pageObject;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import helper.WaitUtil;
import utility.ConfigFileReader;

public class TTHistoricalEOD {

	WebDriver driver;
	ConfigFileReader configFileReader = new ConfigFileReader();
	WaitUtil waitUtil = new WaitUtil();

	@FindBy(xpath = "//span[text()='EOD Balances']")
	private WebElement eodBalances;
	@FindBy(xpath = "//input[@placeholder='Currency']")
	private WebElement currency;
	@FindBy(xpath = "//input[@placeholder='Search bank account']")
	private WebElement bankAccount;
	// @FindBy(xpath="//label[text()='Date
	// From']//following-sibling::div//input[@class='MuiInputBase-input
	// MuiInput-input MuiInputBase-inputAdornedEnd']']") WebElement fromCalendar;
	@FindBy(xpath = "//form/span[3]/div/div/input")
	private WebElement fromCalendar;
	// @FindBy(xpath="//label[text()='Date
	// To']//following-sibling::div//input[@class='MuiInputBase-input MuiInput-input
	// MuiInputBase-inputAdornedEnd']") WebElement toCalendar;
	@FindBy(xpath = "//form/span[4]/div/div/input")
	private WebElement toCalendar;
	@FindBy(xpath = "//button/span[text()=' Search']")
	private WebElement searchButton;
	@FindBy(xpath = "//button/span[text()=' Reset']")
	private WebElement resetButton;
	@FindBy(xpath = "//span[text()='Historical']")
	private WebElement Historical;

	public TTHistoricalEOD(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void clickEOD()

	{

		waitUtil.untilWebElementIsClickable(driver, eodBalances);
		eodBalances.click();
	}

	public void searchEODBalances() throws Exception {

		// enter a currency
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0, -250);");
		Thread.sleep(2000);
		Actions act = new Actions(driver);
		act.moveToElement(currency).click().build().perform();
		act.moveToElement(currency).sendKeys("USD").build().perform();
		act.moveToElement(currency).sendKeys(Keys.ARROW_DOWN).build().perform();
		act.moveToElement(currency).sendKeys(Keys.ENTER).build().perform();

		// enter a bank account
		Thread.sleep(2000);
		act.moveToElement(bankAccount).click().build().perform();
		act.moveToElement(bankAccount).sendKeys("2006").build().perform();
		act.moveToElement(bankAccount).sendKeys(Keys.ARROW_DOWN).click().perform();
		act.moveToElement(bankAccount).sendKeys(Keys.ENTER).click().perform();

		// enter date from
		Thread.sleep(2000);
		act.moveToElement(fromCalendar).click().build().perform();
		act.moveToElement(fromCalendar).sendKeys("01/02/2020").build().perform();
		act.moveToElement(fromCalendar).sendKeys(Keys.ENTER).build().perform();

		// enter date to
		Thread.sleep(2000);
		act.moveToElement(toCalendar).click().build().perform();
		act.moveToElement(toCalendar).sendKeys("29/02/2020").build().perform();
		act.moveToElement(toCalendar).sendKeys(Keys.ENTER).build().perform();

		Thread.sleep(1000);

		// Data Should Not Flow like .sendKey(date) as this wiill create an issue Wle
		// test exictuion while data chage
		// frou data from feature or from the Config or From Excel.. Take Data flow from
		// excel as lest prayority

	}

	public void searchButton() {

		waitUtil.untilWebElementIsClickable(driver, searchButton);
		searchButton.click();

	}
	// hit reset

	public void resetButton() throws Exception {

		waitUtil.untilWebElementIsClickable(driver, resetButton);
		waitUtil.untilPageLoadComplete(driver);
		// Thread.sleep(5000);
		resetButton.click();
	}

}
