package pageObject;

import static org.testng.Assert.assertEquals;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import helper.WaitUtil;
import utility.DriverManager;

public class TTManageAccounts {

	WebDriver driver;
	WaitUtil waitUtil = new WaitUtil();
	DriverManager webDriverManager = new DriverManager();

	@FindBy(xpath = "//button//span[text()='Open Accounts']")
	private WebElement OpenAccountsTab;

	@FindBy(xpath = "//button//span[text()='Closed Accounts']")
	private WebElement ClosedAccountsTab;

	@FindAll(@FindBy(xpath = "//h3[text()='Manage Accounts']/parent::div//div//button//span"))
	private List<WebElement> tablist;

	public TTManageAccounts(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	/**
	 * Validate the tab present in the Account page
	 * 
	 * @param String
	 *            tabNae(Same as that in Web Page )
	 * 
	 * 
	 */
	public void validateTabPresent() {

		waitUtil.untilWebElementIsClickable(driver, OpenAccountsTab);
		assertEquals(OpenAccountsTab.isDisplayed(), true,"Validating Open Accounts Tab");
		assertEquals(ClosedAccountsTab.isDisplayed(), true,"Validating Open Accounts Tab");
		
	}

	/**
	 * navigateToOpenAccounts
	 * 
	 * @param NILL
	 * @return NILL
	 */
	public void navigateToOpenAccounts() {
		waitUtil.untilWebElementIsClickable(driver, OpenAccountsTab);
		OpenAccountsTab.click();

	}

	/**
	 * navigateToClosenAccounts
	 * 
	 * @param NILL
	 * @return NILL
	 */
	public void navigateToCloseAccounts() {
		waitUtil.untilWebElementIsClickable(driver, ClosedAccountsTab);
		ClosedAccountsTab.click();
	}

}
