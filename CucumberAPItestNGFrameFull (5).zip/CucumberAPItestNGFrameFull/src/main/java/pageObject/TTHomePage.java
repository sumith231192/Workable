package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import helper.WaitUtil;
import utility.ConfigFileReader;


public class TTHomePage {

	WebDriver driver;
	ConfigFileReader configFileReader = new ConfigFileReader();
	WaitUtil waitUtil = new WaitUtil();

	// @FindBy(xpath="//a[@title='Bookings']") WebElement Bookings;
	@FindBy(xpath = "//span[text()=' Export']")
	private WebElement Export;
	@FindBy(xpath = "//button//span[text()='Historical']")
	private WebElement Historical;
	@FindBy(xpath = "//button//span[text()='Reconciliation']")
	private WebElement Reconciliation;

	@FindBy(xpath = "//span[text()='ZAR']")
	private WebElement Zar;
	@FindBy(xpath = "//button//span[text()='Accounts']")
	private WebElement AccountsTab;
	@FindBy(xpath = "//button//span[text()='Bookings']")
	private WebElement Bookings;
	@FindBy(xpath = "//div[@data-testid='reconsiliations-grid-wrapper']")
	private WebElement recosoledataGrid;

	@FindBy(xpath = "//div[contains(@class,'MuiGrid-root MuiGrid-item MuiGrid-grid')]")
	private WebElement cacountsgrid;

	public TTHomePage(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	// public TTBookingsPage navigateToBookings() {
	// wb=new WebDriverWait(driver,1000);
	// wb.until(ExpectedConditions.visibilityOf(Export));
	// Bookings.click();
	// return new TTBookingsPage();

	public void navigateToTTHistoricalPayments() {
		System.out.println(driver.getTitle());
		waitUtil.untilWebElementIsClickable(driver, Historical);
		Historical.click();

	}

	public void navigateToHistoricalEOD() {
		waitUtil.untilWebElementVisible(driver, Historical);
		Historical.click();
	}

	
	public void navigateToAccountsPage()
	{
		for(int i=0; i<=2;i++){
			  try{
				  waitUtil.untilPageLoadComplete(driver);
//					waitUtil.untilWebElementStale(driver, AccountsTab);
					waitUtil.sleepSeconds(2);
					AccountsTab.click();
					waitUtil.untilWebElementVisible(driver, cacountsgrid);
			     break;
			  }
			  catch(Exception e){
			     System.out.println(e.getMessage());
			  }
			}
		
	}
	
	public void navigateToBooking()
	{
		for(int i=0; i<=2;i++){
			  try{
				  waitUtil.untilPageLoadComplete(driver);
//					waitUtil.untilWebElementStale(driver, AccountsTab);
					waitUtil.sleepSeconds(2);
					Bookings.click();
					waitUtil.untilWebElementVisible(driver, cacountsgrid);
			     break;
			  }
			  catch(Exception e){
			     System.out.println(e.getMessage());
			  }
			}
	}
	
	public void navigateToReconciliation()
	{
		for(int i=0; i<=2;i++){
			  try{
				  waitUtil.untilPageLoadComplete(driver);

					waitUtil.sleepSeconds(2);
					Reconciliation.click();
					waitUtil.untilWebElementVisible(driver, recosoledataGrid);
			     break;
			  }
			  catch(Exception e){
			     System.out.println(e.getMessage());
			  }
			}
		
	}
	

}
