package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import helper.WaitUtil;
import utility.ConfigFileReader;

import java.util.Arrays;
import java.util.List;

import static org.testng.Assert.assertEquals;

public class TTBookingsPage {
	
	WebDriver driver;
	ConfigFileReader configFileReader = new ConfigFileReader();
	WaitUtil waitUtil = new WaitUtil();
	
	@FindBy(xpath = "//button//span[text()='Unmatched']")
	private WebElement UnmatchedTab;
	@FindBy(xpath = "//button//span[text()='Matched']")
	private WebElement MatchedTab;
	@FindBy(xpath = "//button//span[text()='Exceptions']")
	private WebElement ExceptionsTab;

	@FindAll(@FindBy(xpath="//div[@class='ag-header-viewport']//div[@class='ag-header-row ag-header-row-column']"))
	private List<WebElement> unMatchedList;
	@FindBy(xpath="//div[@class='ag-header-cell-label']//span[text()='Inserted On']")
	private WebElement insertOn;
	@FindBy(xpath="//div[@class='ag-header-cell-label']//span[text()='BIC']")
	private WebElement bic;
	@FindBy(xpath="//div[@class='ag-header-cell-label']//span[text()='Bank Account']")
	private WebElement bankAccount;
	@FindBy(xpath="//div[@class='ag-header-cell-label']//span[text()='Ordering Customer']")
	private WebElement orderingCustomer;
	@FindBy(xpath="//div[@class='ag-header-cell-label']//span[text()='System Account']")
	private WebElement systemAccount;
	@FindBy(xpath="//div[@class='ag-header-cell-label']//span[text()='Business Group']")
	private WebElement businessGroup;
	@FindBy(xpath="//div[@class='ag-header-cell-label']//span[text()='CCY']")
	private WebElement ccy;
	@FindBy(xpath="//div[@class='ag-header-cell-label']//span[text()='Amount']")
	private WebElement amount;
	@FindBy(xpath="//div[@class='ag-header-cell-label']//span[text()='Value Date']")
	private WebElement valueDate;
	@FindBy(xpath="//div[@class='ag-header-cell-label']//span[text()='Search Account']")
	private WebElement searchAccount;
	@FindBy(xpath="//div[@class='ag-header-cell-label']//span[text()='Comment']")
	private WebElement comment;

	
	public TTBookingsPage(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	
	public void navigateToUnMatched()
	{
		waitUtil.untilWebElementIsClickable(driver, UnmatchedTab);
		UnmatchedTab.click();
	}
	public void navigateToMatched()
	{
		waitUtil.untilWebElementIsClickable(driver, MatchedTab);
		MatchedTab.click();
	}
	public void navigateToExceptions()
	{
		waitUtil.untilWebElementIsClickable(driver, ExceptionsTab);
		ExceptionsTab.click();
	}

	public void navigatetoUnmatchedfields()
	{

	}

//	public void validateAllRowBookingHeadingsIsDisplayed(String value) {
//	  boolean validate= true;
//	  String[] arr= value.split(,);
//	  List<String> a1= Arrays.asList(arr);
//	  String etext ="";
//	  for(WebElement ele:unMatchedList)
//	  {
//	  	etext=ele.getText();
//	  	if(!a1.contains(ele.getText().trim())&& a1.contains(!ele.getText().isEmpty())
//	  }




	}

