package utility;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import helper.WaitUtil;
import io.github.bonigarcia.wdm.WebDriverManager;

public class DriverManager {
	ConfigFileReader configFileReader;
	WaitUtil waitUtil = new WaitUtil();
	private WebDriver driver;
	private static DriverManager instance;
	
	
	/*public DriverManager(WebDriver driver) {

		this.driver = driver;
		
	}*/
	public static DriverManager  getInstace()
	{
	if(instance== null)	
	{
		instance= new DriverManager();
	}
	return instance;
	}

	
	public WebDriver getDriver() {
		if (this.driver == null) {

			this.driver = createDriver();

		}

		return this.driver;
	}

	private WebDriver createDriver() {
		this.driver = createLocalDriver();
		return this.driver;
	}

	
	/*
	 * private WebDriver createRemoteDriver() { throw new
	 * RuntimeException("RemoteWebDriver is not yet implemented"); }
	 */

	private WebDriver createLocalDriver() {
		/* goo */
//		killDriver();
		System.out.println("Browser Lauch");
		String browser = "CHROME";
		// Reporter.log(browser);
		if ("CHROME".equalsIgnoreCase(browser)) {

			WebDriverManager.chromedriver().setup();
			this.driver = new ChromeDriver();
			this.driver.manage().window().maximize();
			this.driver.manage().deleteAllCookies();

		} else if ("IE".equalsIgnoreCase(browser.toUpperCase())) {

			WebDriverManager.iedriver().setup();
			this.driver = new InternetExplorerDriver();
			this.driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			this.driver.manage().window().maximize();
			this.driver.manage().deleteAllCookies();

		}

		else if ("firefox".equalsIgnoreCase(browser.toUpperCase())) {
			WebDriverManager.firefoxdriver().setup();
			this.driver = new FirefoxDriver();
			this.driver.manage().window().maximize();
			this.driver.manage().deleteAllCookies();
		}

		return this.driver;

		/*
		 * if ("CHROME".equalsIgnoreCase(browser.toUpperCase())) { // Create a map to
		 * store preferences Map<String, Object> prefs = new HashMap<String, Object>();
		 * 
		 * // add key and value to map as follow to switch off browser notification //
		 * Pass the argument 1 to allow and 2 to block
		 * prefs.put("profile.default_content_setting_values.notifications", 2);
		 * 
		 * // Create an instance of ChromeOptions ChromeOptions options = new
		 * ChromeOptions();
		 * 
		 * // set ExperimentalOption - prefs options.setExperimentalOption("prefs",
		 * prefs); System.setProperty("webdriver.chrome.driver",
		 * "./src/main/resources/Drivers/windows/chromedriver123.exe"); driver = new
		 * ChromeDriver(options); driver.manage().window().maximize();
		 * driver.manage().deleteAllCookies();
		 * 
		 * } else if ("IE".equalsIgnoreCase(browser.toUpperCase())) {
		 * System.setProperty("webdriver.ie.driver",
		 * "./src/main/resources/drivers/IEDriver.exe"); DesiredCapabilities
		 * ieCapabilities = DesiredCapabilities.internetExplorer();
		 * 
		 * ieCapabilities.setCapability(InternetExplorerDriver.
		 * INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		 * ieCapabilities.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION,
		 * true);
		 * 
		 * ieCapabilities.setCapability("ie.ensureCleanSession", true);
		 * 
		 * driver = new InternetExplorerDriver(ieCapabilities);
		 * driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		 * 
		 * driver.manage().window().maximize(); driver.manage().deleteAllCookies();
		 * 
		 * } return driver;
		 */
	}
	
	public void killDriver()

	{
		try {
			Runtime.getRuntime().exec("cmd");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			Runtime.getRuntime().exec("taskkill /F /IM chrome.exe /T");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		waitUtil.sleepSeconds(2);
	}
	public void quitDriver() {
		this.driver.manage().deleteAllCookies();
		this.driver.quit();

//		killDriver();

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

	public void closeDriver() {
		this.driver.manage().deleteAllCookies();
		this.driver.close();
		this.driver = null;
				try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

}