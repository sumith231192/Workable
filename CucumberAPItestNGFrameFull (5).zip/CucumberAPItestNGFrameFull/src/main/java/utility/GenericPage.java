package utility;

import static org.testng.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import helper.CommonHelper;
import helper.WaitUtil;
import utility.ConfigFileReader;

public class GenericPage {

	WebDriver driver;
	ConfigFileReader configFileReader = new ConfigFileReader();
	WaitUtil waitUtil = new WaitUtil();
	CommonHelper commonHelper = new CommonHelper();

	@FindAll(@FindBy(xpath = "//div[@class='ag-header-cell-label']/span[@class='ag-header-cell-text']"))
	private List<WebElement> rowHeadvalues;

	@FindBy(className = "ag-side-button-icon-wrapper")
	private WebElement optionsButton;

	@FindBy(className = "ag-tool-panel-wrapper")
	private WebElement LegentDetails;

	@FindAll(@FindBy(xpath = "//div[@class= 'ag-paging-panel ag-unselectable']//span"))
	private List<WebElement> summaryDetails;
	@FindBy(className = "ag-paging-row-summary-panel")
	private WebElement rowSummaryPannel;
	@FindBy(className = "ag-paging-page-summary-panel")
	private WebElement pageSummaryPannel;
	@FindBy(xpath = "//div//input[@class='ag-input-field-input ag-text-field-input']")
	private WebElement searchFilter;

	@FindBy(xpath = "//span[@class='ag-tab ag-tab-selected']/span[@class='ag-icon ag-icon-filter']")
	private WebElement iconFilter;
	@FindBy(xpath = "//div[@class='ag-tabs-header ag-menu-header']/span/span[@class='ag-icon ag-icon-columns']")
	private WebElement iconColumn;
	@FindBy(xpath = "//div[@class='ag-tabs-header ag-menu-header']/span/span[@class='ag-icon ag-icon-menu']")
	private WebElement iconMenu;

	@FindAll(@FindBy(xpath = "//div[@class= 'ag-virtual-list-viewport ag-filter-virtual-list-viewport']//div//span"))
	private List<WebElement> iconfilterdata;
	@FindBy(xpath = "//input[@class='ag-input-field-input ag-text-field-input']")
	private WebElement searchBox;

	@FindBy(xpath = "//div[@class='ag-menu-list']")
	private WebElement menudetails;
	@FindBy(xpath = "//h3[contains(@class, 'MuiTypography-root MuiTypography-h4') and text() = 'Manage Accounts']")
	private WebElement manageAccountsHeader;

	@FindBy(xpath = "//span[contains(@class, 'ag-menu-option-text ag-menu-option-part') and text() = 'Pin Column']")
	private WebElement pingColumn;
	@FindBy(xpath = "//div[@class='ag-menu ag-ltr ag-popup-child']")
	private WebElement pingColumnChildMenu;

	@FindAll(@FindBy(xpath = "//div[@class='ag-header-cell-resize']"))
	private List<WebElement> resizerList;

	@FindBy(xpath = "//div[@class='ag-body-horizontal-scroll-viewport']")
	WebElement scrollbar;

	@FindBy(xpath = "//span[contains(@class, 'ag-set-filter-item-value') and text() = '(Select All)']")
	private WebElement selectAll;
	@FindBy(xpath = "//span[contains(@class, 'ag-set-filter-item-value') and text() = '(Blanks)']")
	private WebElement balnks;
	@FindBy(xpath = "//span[contains(@class, 'ag-set-filter-item-value') and text() = 'false']")
	private WebElement falseSegList;
	@FindBy(xpath = "//span[contains(@class, 'ag-set-filter-item-value') and text() = 'true']")
	private WebElement trueSegList;
	@FindAll(@FindBy(xpath = "//div[@class='ag-wrapper ag-input-wrapper ag-checkbox-input-wrapper ag-checked']//parent::div//parent::label//span[@class='ag-set-filter-item-value']"))
	private List<WebElement> filtercheckedList;
	@FindAll(@FindBy(xpath = "//div[@class='ag-wrapper ag-input-wrapper ag-checkbox-input-wrapper']//parent::div//parent::label//span[@class='ag-set-filter-item-value']"))
	private List<WebElement> filterUncheckedList;

	@FindBy(xpath = "//div[@class='ag-column-select-header-checkbox ag-labeled ag-label-align-right ag-checkbox ag-input-field']//input[@type='checkbox']")
	private WebElement selectAllColumn;
	@FindAll(@FindBy(xpath = "//div[@class='ag-wrapper ag-input-wrapper ag-checkbox-input-wrapper ag-checked']//parent::div//parent::div//span[@class='ag-column-select-column-label']"))
	private List<WebElement> chekedCheckBoxColumn;
	@FindAll(@FindBy(xpath = "//div[@class='ag-wrapper ag-input-wrapper ag-checkbox-input-wrapper']//parent::div//parent::div//span[@class='ag-column-select-column-label']"))
	private List<WebElement> unchekedCheckBoxColumn;
	@FindAll(@FindBy(xpath = "//div[@class='ag-header-cell-label']//span[@class='ag-header-cell-text']"))
	private List<WebElement> filter_entry_ColumHead;
	@FindBy(xpath = "//div[@class='ag-filter-apply-panel']//button[@class='ag-standard-button ag-filter-apply-panel-button']")
	private WebElement clearFilterButton;
	@FindAll(@FindBy(xpath = "//div[@col-id='segregation']"))
	private List<WebElement> segregationRowDataValues;
	@FindAll(@FindBy(xpath = "//div[@class='ag-center-cols-clipper']//div[@col-id='cutOffTime']"))
	private List<WebElement> BankCutOffRowDataValues;
	@FindBy(xpath = "(//div[@class='ag-wrapper ag-picker-field-wrapper']//div[@class='ag-picker-field-display'])[1]")
	private WebElement swiftTimeSelectFirst;
	@FindBy(xpath = "(//input[@class='ag-input-field-input ag-text-field-input'])[1]")
	private WebElement swiftTimeDateFirst;
	@FindBy(xpath = "(//input[@class='ag-input-field-input ag-text-field-input'])[2]")
	private WebElement swiftTimeDateSecond;
	@FindAll(@FindBy(xpath = "//div[@class='ag-center-cols-clipper']//div[@col-id='swiftMessageTime']"))
	private List<WebElement> swiftRowDataValues;
	@FindAll(@FindBy(xpath = "//div[@col-id='accountNumber']"))
	private List<WebElement> accountNumberDataColumnvaluesList;
	@FindBy(id = "generic-modal-title")
	private WebElement accountDetaislPopUpHeader;
	@FindBy(className = "MuiPaper-root MuiDialog-paper MuiDialog-paperScrollPaper MuiDialog-paperWidthXl MuiPaper-elevation24 MuiPaper-rounded")
	private WebElement accountDetaislPopUpDilogbox;
	@FindAll(@FindBy(xpath = "//div[@class='MuiGrid-root MuiGrid-container MuiGrid-spacing-xs-4 MuiGrid-justify-xs-center']//label"))
	private List<WebElement> accountDetaislPopUpLabels;
	@FindBy(xpath = "//div[@data-testid='form-control-bank-cut-off-time']")
	private WebElement bankCutOffTime;
	@FindAll(@FindBy(xpath = "//span[@class='MuiTypography-root MuiPickersClockNumber-clockNumber MuiTypography-body1']"))
	private List<WebElement> bankCFTimeClockHR1;
	@FindAll(@FindBy(xpath = "//span[@class='MuiTypography-root MuiPickersClockNumber-clockNumber MuiTypography-body2']"))
	private List<WebElement> bankCFTimeClockHR2;
	@FindBy(xpath = "//div[@class='MuiPickersClockPointer-thumb MuiPickersClockPointer-noPoint']")
	private WebElement clockTipHR;
	@FindBy(xpath = "//div[starts-with(@class, 'MuiPickersClockPointer-thumb')]")
	private WebElement clockTipMM;
	@FindBy(xpath = "//div[@class='MuiPickersTimePickerToolbar-hourMinuteLabel']//button[2]")
	private WebElement minutesPostion;
	@FindBy(xpath = "//button//span[text()='Save Changes']")
	private WebElement saveButtonAccountDetails;
	@FindBy(xpath = "//button//span[text()='Deactivate']")
	private WebElement deactivateButtonAccountDetails;
	@FindBy(xpath = "//div[@class='MuiSelect-root MuiSelect-select MuiSelect-selectMenu MuiInputBase-input MuiInput-input']")
	private WebElement mutliSelectLegalEntiti;
	@FindAll(@FindBy(xpath = "//li[@class='MuiButtonBase-root MuiListItem-root MuiMenuItem-root MuiMenuItem-gutters MuiListItem-gutters MuiListItem-button']"))
	private List<WebElement> listValueMutliSelectLegalEntiti;
	@FindBy(xpath = "//span[@ref='lbRecordCount']")
	private WebElement maxRecdData;
	@FindBy(xpath = "//div[@ref='btNext']")
	private WebElement nextPage;

	@FindBy(xpath ="//div[@class='ag-header-container']")
	private WebElement HeaderLabels;
	public GenericPage(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void clickIconColumn() {
		waitUtil.untilWebElementIsClickable(driver, iconColumn);
		iconColumn.click();
	}

	public void setSearchFilter(String datSearch) {
		waitUtil.untilWebElementVisible(driver, searchBox);
		searchBox.sendKeys(datSearch);
	}

	public WebElement getSearchFilter(String datSearch) {
		waitUtil.sleepSeconds(2);
		WebElement ele = driver.findElement(
				By.xpath("//span[contains(@class, 'ag-set-filter-item-value') and text() = '" + datSearch + "']"));
		return ele;
	}

	public void selectSearchFilter(String datSearch) {
		WebElement ele = getSearchFilter(datSearch);
		waitUtil.untilWebElementIsClickable(driver, ele);
		ele.click();
	}

	public WebElement getColumnLabel(String datSearch) {
		waitUtil.sleepSeconds(2);
		WebElement ele = driver.findElement(
				By.xpath("//span[contains(@class, 'ag-column-select-column-label') and text() = '" + datSearch + "']"));
		return ele;
	}

	public void validateAllrowHeadingsIsDisaplyed(String value) {
		boolean validate = true;
		String[] arrVal = value.split(",");
		List<String> valList = Arrays.asList(arrVal);
		String eletxt = "";
		waitUtil.sleepSeconds(2);
		for (WebElement ele : rowHeadvalues) {
			eletxt = ele.getText();
			System.out.println("  text is :" + eletxt + "");
			if (!valList.contains(ele.getText().trim()) && !ele.getText().isEmpty()) {
				validate = false;
				System.out.println("Missing  text is :" + eletxt + "");
			}
		}
		assertEquals(validate, true, "Validation of all header values " + value);
	}

	public void validaterowSummaryPanel(String fromOfexp) {

		if (rowSummaryPannel.getText().contains(fromOfexp.split(",")[0])
				&& rowSummaryPannel.getText().contains(fromOfexp.split(",")[1])) {
			assertEquals(true, true, "Validation of Summary Pannel:" + rowSummaryPannel.getText());
		} else {
			assertEquals(false, true, "Validation of Summary Pannel:" + rowSummaryPannel.getText());
		}

	}

	public void validatePageSummarPannel(String pagesfromOf) {
		if (pageSummaryPannel.getText().contains(pagesfromOf.split(",")[0])
				&& pageSummaryPannel.getText().contains(pagesfromOf.split(",")[1])) {
			assertEquals(true, true, "Validation of Summary Pannel:" + pageSummaryPannel.getText());
		} else {
			assertEquals(false, true, "Validation of Summary Pannel:" + pageSummaryPannel.getText());
		}
	}

	public void clickResize() {
		waitUtil.sleepSeconds(2);
		Actions action = new Actions(driver);

		for (WebElement el : resizerList) {
			if (el.isDisplayed()) {
				action.moveToElement(el).doubleClick().build().perform();
				waitUtil.sleepSeconds(1);
			}

		}

	}

	public void clickfilterIcon(String rowHead) {
		waitUtil.untilPageLoadComplete(driver);
		waitUtil.untilWebElementVisible(driver, HeaderLabels);
		String path1 = "//div[@class='ag-header-cell-label']/span[@class='ag-header-cell-text'][contains(text(),'";
		String path2 = "')]//parent::div//parent::div//span[@class='ag-icon ag-icon-menu']";
		WebElement ele = null;
		Actions action = new Actions(driver);
		WebElement filterbutton = null;
		
//		if (LegentDetails.isDisplayed()) {
//			optionsButton.click();
//		}
		waitUtil.sleepSeconds(3);
	

		ele = driver.findElement(By.xpath(
				"//div[@class='ag-header-cell-label']//span[contains(@class, 'ag-header-cell-text') and text() = '"
						+ rowHead +"']"));

		waitUtil.sleepSeconds(1);

		action.moveToElement(ele).perform();
		waitUtil.sleepSeconds(1);
		try {
			filterbutton = driver.findElement(By.xpath(path1 + rowHead + path2));
			filterbutton.click();
		} catch (Exception NoSuchElementException) {
			action.clickAndHold(scrollbar).moveByOffset(100, 0).build().perform();
			waitUtil.sleepSeconds(1);
			action.moveToElement(ele).perform();
			filterbutton = driver.findElement(By.xpath(path1 + rowHead + path2));
			filterbutton.click();
		}

	}

	public void validateFiltervaluesInROwHead(String values) {
		List<String> expFilterlist = Arrays.asList(values.split(","));
		waitUtil.sleepSeconds(1);
		waitUtil.untilWebElementVisible(driver, searchBox);
		for (String delta : expFilterlist) {
			setSearchFilter(delta);
			WebElement ele = getSearchFilter(delta);
			assertEquals(ele.isDisplayed(), true, "Validated the set-filter-item-value:" + ele.getText());
			searchBox.clear();
		}

	}

	public void validateColumnValuesInrowHead(String values) {
		List<String> expFilterlist = Arrays.asList(values.split(","));
		clickIconColumn();
		waitUtil.sleepSeconds(1);
		waitUtil.untilWebElementVisible(driver, searchBox);
		for (String delta : expFilterlist) {
			setSearchFilter(delta);
			waitUtil.sleepSeconds(2);
			WebElement ele = getColumnLabel(delta);

			assertEquals(ele.isDisplayed(), true, "Validated the ColumnData:" + delta);
			searchBox.clear();

		}

	}

	public void validateMenuVlauesInRowHead(String values) {
		List<String> expFilterlist = Arrays.asList(values.split(","));
		List<String> actuual = new ArrayList<>();
		waitUtil.sleepSeconds(1);
		iconMenu.click();
		String[] mendetarr = menudetails.getText().split("\n");
		for (String b : mendetarr) {
			actuual.add(b.trim());
		}
		for (String delta : expFilterlist) {
			assertEquals(actuual.contains(delta), true, "Validation MenuData");
		}

	}

	public void validatePingColumnOptions(String values) {

		List<String> expFilterlist = Arrays.asList(values.split(","));
		List<String> actuual = new ArrayList<>();
		pingColumn.click();
		String[] mendetarr = pingColumnChildMenu.getText().split("\n");
		for (String b : mendetarr) {
			actuual.add(b.trim());
		}
		for (String delta : expFilterlist) {
			assertEquals(actuual.contains(delta), true, "Validation ChildMenu Data");
		}

	}

	public void clickSelectAll() {

		if (!filtercheckedList.isEmpty()) {
			selectAll.click();
			waitUtil.sleepSeconds(2);
		}

	}

	

	public void clickClearFilterButton() {
		waitUtil.untilWebElementVisible(driver, clearFilterButton);
		clearFilterButton.click();

	}

	public void validateValueDisplayedAfterClearColumnFilter(String allvalues, String filtercount) {
		List<String> listArr = Arrays.asList(allvalues.split(","));
		Collections.shuffle(listArr);
		List<String> filterCountData = new ArrayList<>();
		int filval = Integer.parseInt(filtercount);
		// waitUtil.untilWebElementVisible(driver, selectAllColumn);
		// selectAllColumn.isDisplayed();
		// selectAllColumn.click();
		for (WebElement ele : chekedCheckBoxColumn) {
			ele.click();
		}

		for (int k = 0; k <= filval - 1; k++) {
			setSearchFilter(listArr.get(k));
			filterCountData.add(listArr.get(k).trim());
			waitUtil.sleepSeconds(1);
			WebElement eleToclci = driver.findElement(By.xpath(
					"//span[contains(@class, 'ag-column-select-column-label') and text() = '" + listArr.get(k) + "']"));
			eleToclci.click();
			waitUtil.sleepSeconds(1);
			searchBox.clear();

			for (WebElement ele : filter_entry_ColumHead) {
				if (!ele.getText().trim().equalsIgnoreCase("Legal Entity")) {
					// System.out.println(ele.getText().trim());
					assertEquals(filterCountData.contains(ele.getText().trim()), true,
							" Validation of Filtervalue Column");

				}
			}

		}
	}

	public void validateTheColumFilterOneByOne() {
		if (!chekedCheckBoxColumn.isEmpty()) {
			do {
				for (WebElement ele : chekedCheckBoxColumn) {
					ele.click();
				}

			} while (unchekedCheckBoxColumn.isEmpty());
		}
		for (WebElement ele : unchekedCheckBoxColumn) {
			ele.click();
			for (WebElement columnele : filter_entry_ColumHead) {

				assertEquals(columnele.getText().trim().equalsIgnoreCase(ele.getText().trim()), true,
						" Validation of Filtervalue Column:" + columnele.getText().trim() + ":" + ele.getText().trim());
				ele.click();

			}
		}

	}

	public void validateFilterOnebyOneWithFilterValueAndData(String values) {
		List<String> expFilterlist = Arrays.asList(values.split(","));
		// clickIconColumn();
		waitUtil.untilWebElementVisible(driver, searchBox);
		for (String delta : expFilterlist) {
			setSearchFilter(delta);
			waitUtil.sleepSeconds(2);
			WebElement ele = driver.findElement(
					By.xpath("//span[contains(@class, 'ag-set-filter-item-value') and text() = '" + delta + "']"));

			assertEquals(ele.isDisplayed(), true, "Validated the ColumnData:" + delta);
			ele.click();
			waitUtil.sleepSeconds(2);
			for (WebElement elementBank : BankCutOffRowDataValues) {
				assertEquals(elementBank.getText().trim().equals(delta), true,
						"Validating Data displayed From filtervalue" + delta);
			}
			selectAll.click();
			searchBox.clear();

		}
		clearFilterButton.click();

	}

}
