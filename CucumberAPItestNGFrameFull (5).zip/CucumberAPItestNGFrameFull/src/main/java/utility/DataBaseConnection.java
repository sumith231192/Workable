package utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Objects;

public class DataBaseConnection {

	DataBaseReader dataBaseReader;
	ConfigFileReader configFileReader = new ConfigFileReader();

	public String getDbResult(String query) throws ClassNotFoundException, SQLException {
		dataBaseReader = new DataBaseReader();
		String dbUrl = dataBaseReader.getDBurl();
		String username = dataBaseReader.getUserID();
		String password = dataBaseReader.getPassword();
		Connection con = null;
		String DB_Result = null;
		String user = dataBaseReader.getStafId();
		// System.out.println("******" + dbUrl + "*****" + username + "*******" +
		// password);

		try {

			Class.forName("oracle.jdbc.OracleDriver");
			con = DriverManager.getConnection(dbUrl, username, password);
			Statement stmt = con.createStatement();
			stmt.executeQuery("begin  security.set_staff_id('" + user + "','','','',''); END;");
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				DB_Result = rs.getString(1);
				System.out.println("Result from DB" + DB_Result);

			}

		} catch (Exception e) {
			System.out.println(e);

		} finally {
			System.out.println("Closing the DB connection...............");
			con.close();
		}
		return DB_Result;

	}

	public HashMap<String, String> getMultiDbResult(String query) throws ClassNotFoundException, SQLException {
		dataBaseReader = new DataBaseReader();
		String dbUrl = dataBaseReader.getDBurl();
		String username = dataBaseReader.getUserID();
		String password = dataBaseReader.getPassword();
		Connection con = null;
		String staf_id = dataBaseReader.getStafId();
		HashMap<String, String> resultHash = new HashMap<>();
		try {

			Class.forName("oracle.jdbc.OracleDriver");
			con = DriverManager.getConnection(dbUrl, username, password);
			Statement stmt = con.createStatement();
			stmt.executeQuery("begin  security.set_staff_id('" + staf_id + "','','','',''); END;");
			ResultSet rs = stmt.executeQuery(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			while (rs.next()) {
				// System.out.println(rsmd.getco);

				for (int i = 1; i <= rsmd.getColumnCount(); i++) {

					resultHash.put(rsmd.getColumnName(i), rs.getNString(i));

				}

				System.out.println("Result from DB" + resultHash);

			}

		} catch (Exception e) {
			System.out.println(e);

		} finally {
			System.out.println("Closing the DB connection");
			con.close();
		}
		resultHash.values().removeIf(Objects::isNull);
		return resultHash;

	}

	public void updateDB(String query) throws SQLException {

		dataBaseReader = new DataBaseReader();
		String dbUrl = dataBaseReader.getDBurl();
		String username = dataBaseReader.getUserID();
		String password = dataBaseReader.getPassword();
		Connection con = null;

		String user = dataBaseReader.getStafId();

		try {

			Class.forName("oracle.jdbc.OracleDriver");
			con = DriverManager.getConnection(dbUrl, username, password);
			Statement stmt = con.createStatement();
			// stmt.executeQuery(dataBaseReader.setSecutityforNOADM());
			stmt.executeQuery("begin  security.set_staff_id('" + user + "','','','',''); END;");
			stmt.executeQuery(query);
			stmt.executeQuery("COMMIT;");
		} catch (Exception e) {
			System.out.println(e);

		} finally {
			System.out.println("Closing the DB connection");
			con.close();
		}

	}

	

}